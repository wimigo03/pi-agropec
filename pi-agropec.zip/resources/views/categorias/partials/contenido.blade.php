<div class="form-group row">
    <div class="col-md-4 pr-1 font-roboto-12 text-right">
        <label for="nombre" class="d-inline">Categoria </label>
    </div>
    <div class="col-md-8 pl-1 font-roboto-12">
        <span class="font-roboto-12" id="nombre"></span>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-4 pr-1 font-roboto-12 text-right">
        <label for="nivel" class="d-inline">Nivel </label>
    </div>
    <div class="col-md-8 pl-1 font-roboto-12">
        <span class="font-roboto-12" id="nivel"></span>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-4 pr-1 font-roboto-12 text-right">
        <label for="detalle" class="d-inline">Detalle </label>
    </div>
    <div class="col-md-8 pl-1 font-roboto-12">
        <span class="font-roboto-12" id="detalle"></span>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-4 pr-1 font-roboto-12 text-right">
        <label for="codigo" class="d-inline">Codigo </label>
    </div>
    <div class="col-md-8 pl-1 font-roboto-12">
        <span class="font-roboto-12" id="codigo"></span>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-4 pr-1 font-roboto-12 text-right">
        <label for="numeracion" class="d-inline">Numeracion </label>
    </div>
    <div class="col-md-8 pl-1 font-roboto-12">
        <span class="font-roboto-12" id="numeracion"></span>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-4 pr-1 font-roboto-12 text-right">
        <label for="tipo" class="d-inline">Tipo </label>
    </div>
    <div class="col-md-8 pl-1 font-roboto-12">
        <span class="font-roboto-12" id="tipo"></span>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-4 pr-1 font-roboto-12 text-right">
        <label for="estado" class="d-inline">Estado </label>
    </div>
    <div class="col-md-8 pl-1 font-roboto-12">
        <span class="font-roboto-12" id="estado"></span>
    </div>
</div>