<div class="form-group row">
    <div class="col-md-12 font-verdana">
        <label for="nombre" class="d-inline">Cargo.- </label>
        <span class="font-verdana" id="nombre"></span>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-12 font-verdana">
        <label for="codigo" class="d-inline">Codigo.- </label>
        <span class="font-verdana" id="codigo"></span>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-12 font-verdana">
        <label for="email" class="d-inline">Email.- </label>
        <span class="font-verdana" id="email"></span>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-12 font-verdana">
        <label for="descripcion" class="d-inline">Descripcion.- </label>
        <span class="font-verdana" id="descripcion"></span>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-12 font-verdana">
        <label for="alias" class="d-inline">Alias</label>
        <span class="font-verdana" id="alias"></span>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-12 font-verdana">
        <label for="estado" class="d-inline">Estado</label>
        <span class="font-verdana" id="estado"></span>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-12 font-verdana">
        <label for="tipo" class="d-inline">Tipo</label>
        <span class="font-verdana" id="tipo"></span>
    </div>
</div>