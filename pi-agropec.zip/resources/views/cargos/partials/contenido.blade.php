<div class="form-group row">
    <div class="col-md-11 pr-1 font-roboto-12">
        <label for="nombre" class="d-inline">Cargo.- </label>
        <span class="font-roboto-12" id="nombre"></span>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-11 pr-1 font-roboto-12">
        <label for="codigo" class="d-inline">Codigo.- </label>
        <span class="font-roboto-12" id="codigo"></span>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-11 pr-1 font-roboto-12">
        <label for="email" class="d-inline">Email.- </label>
        <span class="font-roboto-12" id="email"></span>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-11 pr-1 font-roboto-12">
        <label for="descripcion" class="d-inline">Descripcion.- </label>
        <span class="font-roboto-12" id="descripcion"></span>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-11 pr-1 font-roboto-12">
        <label for="alias" class="d-inline">Alias.- </label>
        <span class="font-roboto-12" id="alias"></span>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-11 pr-1 font-roboto-12">
        <label for="estado" class="d-inline">Estado.- </label>
        <span class="font-roboto-12" id="estado"></span>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-11 pr-1 font-roboto-12">
        <label for="tipo" class="d-inline">Tipo.- </label>
        <span class="font-roboto-12" id="tipo"></span>
    </div>
</div>