{{--@extends('adminlte::page')--}}
{{--@section('title', 'Dashboard')--}}
{{--@section('content_header')
    <h1>Dashboard</h1>
@stop--}}
{{--@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop--}}
{{--<link rel="stylesheet" href="/css/admin_custom.css" rel="stylesheet">
<link rel="stylesheet" href="/css/font-verdana.css" rel="stylesheet">
<style>
    
</style>--}}
{{-----@yield('styles')----}}

{{----@yield('content')-----}}
{{--@section('content')
    <p>Welcome to this beautiful admin panel.</p>
@stop--}}

{{-----@yield('scripts')-----}}

{{--@section('js')
    <script> console.log('Hi!'); </script>
@stop--}}