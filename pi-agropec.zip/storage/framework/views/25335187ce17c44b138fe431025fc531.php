<form action="#" method="post" id="form">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="mesa_id" value="<?php echo e($mesa->id); ?>" id="mesa_id">
    <input type="hidden" name="cliente_id" value="<?php echo e($empresa->cliente_id); ?>" id="cliente_id">
    <input type="hidden" name="empresa_id" value="<?php echo e($empresa->id); ?>">
    <div class="form-group row font-roboto-12">
        <div class="col-md-4 px-0 pr-1">
            <label for="sucursal" class="d-inline">Sucursal</label>
            <div class="select2-container--obligatorio" id="obligatorio_sucursal_id">
                <select name="sucursal_id" id="sucursal_id" class="form-control select2" onchange="obligatorio();">
                    <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sucursal->id); ?>"
                            <?php if($sucursal->id == old('sucursal_id') || (isset($mesa) && $mesa->sucursal_id == $sucursal->id)): ?>
                                selected
                            <?php endif; ?>>
                            <?php echo e($sucursal->nombre); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>                
            </div>
        </div>
        <div class="col-md-4">
            <label for="zona" class="d-inline">Zona</label>
            <div class="select2-container--obligatorio" id="obligatorio_zona_id">
                <select id="zona_id" name="zona_id" class="form-control font-verdana-bg select2" onchange="obligatorio();">
                    <option value="">--Seleccionar--</option>
                </select>
            </div>
        </div>
        <div class="col-md-2 pr-1 pl-1">
            <label for="numero" class="d-inline">N° de Mesa</label>
            <input type="text" name="numero" value="<?php echo e($mesa->numero); ?>" id="numero" class="form-control font-roboto-12 obligatorio intro" oninput="this.value = this.value.toUpperCase(); obligatorio();">
        </div>
        <div class="col-md-2 px-0 pl-1">
            <label for="sillas" class="d-inline">Cant. Sillas</label>
            <input type="text" name="sillas" value="<?php echo e($mesa->sillas); ?>" id="sillas" class="form-control font-roboto-12 obligatorio intro" oninput="this.value = this.value.toUpperCase(); obligatorio();">
        </div>
    </div>
    <div class="form-group row font-roboto-12">
        <div class="col-md-11 px-0 pr-1">
            <label for="detalle" class="d-inline">Descripcion</label>
            <input type="text" name="detalle" value="<?php echo e($mesa->detalle); ?>" id="detalle" class="form-control font-roboto-12 intro" oninput="this.value = this.value.toUpperCase();">
        </div>
    </div>
</form><?php /**PATH D:\SistemaVentas\ventas\resources\views/mesas/partials/form-editar.blade.php ENDPATH**/ ?>