<form action="#" method="get" id="form">
    <input type="hidden" name="empresa_id" value="<?php echo e($empresa->id); ?>">
    <div class="form-group row">
        <div class="col-md-3 px-0 pr-1">
            <select name="tipo_precio_id" id="tipo_precio_id" class="form-control">
                <option value="">-</option>
                <?php $__currentLoopData = $tipo_precios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($index); ?>" <?php if(request('tipo_precio_id') == $index): ?> selected <?php endif; ?> ><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3 pr-1 pl-1">
            <select name="categoria_master_id" id="categoria_master_id" class="form-control">
                <option value="">-</option>
                <?php $__currentLoopData = $categorias_master; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($index); ?>" <?php if(request('categoria_master_id') == $index): ?> selected <?php endif; ?> ><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3 pr-1 pl-1">
            <select id="categoria_id" name="categoria_id" class="form-control font-roboto-12">
                <option value="">--Seleccionar--</option>
            </select>
        </div>
        <div class="col-md-3 px-0 pl-1">
            <input type="text" name="codigo" placeholder="--Codigo--" value="<?php echo e(request('codigo')); ?>" class="form-control font-roboto-12 intro" oninput="this.value = this.value.toUpperCase()">
        </div>
    </div>
    <div class="form-group row">
        <div class="col-md-6 px-0 pr-1">
            <input type="text" name="producto" placeholder="--Producto--" value="<?php echo e(request('producto')); ?>" class="form-control font-roboto-12 intro" oninput="this.value = this.value.toUpperCase()">
        </div>
        
        <div class="col-md-6 px-0 pl-1 text-right">
            <button class="btn btn-outline-primary font-verdana" type="button" onclick="search();">
                <i class="fas fa-search fa-fw"></i>&nbsp;Buscar
            </button>
            <button class="btn btn-outline-danger font-verdana" type="button" onclick="limpiar();">
                <i class="fas fa-eraser fa-fw"></i>&nbsp;Limpiar
            </button>
            <i class="fa fa-spinner fa-spin fa-lg fa-fw spinner-btn" style="display: none;"></i>
        </div>
    </div>
</form>
<?php /**PATH D:\SistemaVentas\ventas\resources\views/precio_productos/partials/search.blade.php ENDPATH**/ ?>