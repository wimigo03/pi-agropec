<!DOCTYPE html>

<style>
    .select2 + .select2-container .select2-selection__rendered {
        font-size: 13px;
    }
    .select2-results__option {
        font-size: 13px;
    }
</style>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('productos.partials.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('productos.partials.form-show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <?php echo $__env->make('layouts.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ready(function() {
            $("#subMenuProductos").hide();
        });

        $("#toggleSubMenu").click(function(){
            $("#subMenuProductos").slideToggle(250);
        });
        
        function pdf(){
            var id = $("#producto_id").val()
            var url = "<?php echo e(route('productos.pdf',':id')); ?>";
            url = url.replace(':id',id);
            window.open(url, '_blank');
        }

        function index(){
            $(".btn").hide();
            $(".spinner-btn").show();
            var id = $("#empresa_id").val();
            var url = "<?php echo e(route('productos.index',':id')); ?>";
            url = url.replace(':id',id);
            window.location.href = url;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SistemaVentas\ventas\resources\views/productos/show.blade.php ENDPATH**/ ?>