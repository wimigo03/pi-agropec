<div class="nav-menu font-roboto-15">
    <ul>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['clientes.index','users.index','roles.index','permissions.index'])): ?>
            <li>
                <a href="" data-toggle="collapse" data-target="#dashboard_setting" class="active collapsed" aria-expanded="false">
                    <i class="fa-solid fa-gear fa-fw mr-1"></i>&nbsp;Administracion
                    <span class="fa fa-arrow-circle-left float-right"></span>
                </a>
                <ul class="sub-menu collapse" id="dashboard_setting">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clientes.index')): ?>
                        <li>
                            <a href="<?php echo e(route('clientes.index')); ?>">
                                &nbsp;&nbsp;<i class="fas fa-address-card fa-fw mr-2"></i>&nbsp;Clientes
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.index')): ?>
                        <li>
                            <a href="<?php echo e(route('users.indexAfter')); ?>">
                                &nbsp;&nbsp;<i class="fas fa-users fa-fw mr-2"></i>&nbsp;Usuarios
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.index')): ?>
                        <li>
                            <a href="<?php echo e(route('roles.indexAfter')); ?>">
                                &nbsp;&nbsp;<i class="fas fa-user-shield fa-fw mr-2"></i>&nbsp;Roles
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permissions.index')): ?>
                        <li>
                            <a href="<?php echo e(route('permissions.indexAfter')); ?>">
                                &nbsp;&nbsp;<i class="fas fa-user-cog fa-fw mr-2"></i>&nbsp;Permisos
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('configuracion.index')): ?>
            <li>
                <a href="<?php echo e(route('configuracion.indexAfter')); ?>">
                    <i class="fa-solid fa-gear fa-fw mr-1"></i>&nbsp;Configuracion
                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['estado.resultado.index','balance.apertura.index','plan.cuentas.index','plan.cuentas.auxiliar.index','tipo.cambio.index','comprobante.index'])): ?>
            <li>
                <a href="" data-toggle="collapse" data-target="#dashboard_contabilidad" class="active collapsed" aria-expanded="false">
                    <i class="fa-solid fa-layer-group fa-fw mr-1"></i>&nbsp;Contabilidad
                    <span class="fa fa-arrow-circle-left float-right"></span>
                </a>
                <ul class="sub-menu collapse" id="dashboard_contabilidad">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('comprobante.index')): ?>
                        <li>
                            <a href="<?php echo e(route('comprobante.indexAfter')); ?>">
                                &nbsp;&nbsp;<i class="fa-solid fa-file-invoice-dollar fa-fw mr-2"></i>&nbsp;Comprobantes
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('balance.apertura.index')): ?>
                        <li>
                            <a href="<?php echo e(route('balance.apertura.indexAfter')); ?>">
                                &nbsp;&nbsp;<i class="fa-solid fa-layer-group fa-fw mr-2"></i>&nbsp;Balance Apertura
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['estado.resultado.index'])): ?>
                        <li>
                            <a href="" data-toggle="collapse" data-target="#dashboard_reportes_contabilidad" class="active collapsed" aria-expanded="false">
                                &nbsp;&nbsp;<i class="fa-solid fa-list fa-fw mr-1"></i>&nbsp;Reportes
                                <span class="fa fa-arrow-circle-left float-right"></span>
                            </a>
                            <ul class="sub-menu collapse" id="dashboard_reportes_contabilidad">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('estado.resultado.index')): ?>
                                    <li>
                                        <a href="<?php echo e(route('estado.resultado.indexAfter')); ?>">
                                            &nbsp;&nbsp;&nbsp;&nbsp;<i class="fa-solid fa-layer-group fa-fw mr-2"></i>&nbsp;Estado de Resultado
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('balance.general.index')): ?>
                                    <li>
                                        <a href="<?php echo e(route('balance.general.indexAfter')); ?>">
                                            &nbsp;&nbsp;&nbsp;&nbsp;<i class="fa-solid fa-layer-group fa-fw mr-2"></i>&nbsp;Balance General
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['libro.mayor.cuenta.general.index','libro.mayor.auxiliar.general.index'])): ?>
                        <li>
                            <a href="" data-toggle="collapse" data-target="#dashboard_libros_contabilidad" class="active collapsed" aria-expanded="false">
                                &nbsp;&nbsp;<i class="fa-solid fa-list fa-fw mr-1"></i>&nbsp;Libros
                                <span class="fa fa-arrow-circle-left float-right"></span>
                            </a>
                            <ul class="sub-menu collapse" id="dashboard_libros_contabilidad">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('libro.mayor.cuenta.general.index')): ?>
                                    <li>
                                        <a href="<?php echo e(route('libro.mayor.cuenta.general.indexAfter')); ?>">
                                            &nbsp;&nbsp;&nbsp;&nbsp;<i class="fa-solid fa-layer-group fa-fw mr-2"></i>&nbsp;Mayor Por Cuenta-General
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('libro.mayor.auxiliar.general.index')): ?>
                                    <li>
                                        <a href="<?php echo e(route('libro.mayor.auxiliar.general.indexAfter')); ?>">
                                            &nbsp;&nbsp;&nbsp;&nbsp;<i class="fa-solid fa-layer-group fa-fw mr-2"></i>&nbsp;Mayor Por Auxiliar-General
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tipo.cambio.index')): ?>
                        <li>
                            <a href="<?php echo e(route('tipo.cambio.indexAfter')); ?>">
                                &nbsp;&nbsp;<i class="fa-solid fa-circle-dollar-to-slot fa-fw mr-2"></i>&nbsp;Tipo de Cambio
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('plan.cuentas.index')): ?>
                        <li>
                            <a href="<?php echo e(route('plan_cuentas.indexAfter')); ?>">
                                &nbsp;&nbsp;<i class="fa-regular fa-chart-bar fa-fw mr-2"></i>&nbsp;Plan de Cuentas
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('plan.cuentas.auxiliar.index')): ?>
                        <li>
                            <a href="<?php echo e(route('plan_cuentas.auxiliar.indexAfter')); ?>">
                                &nbsp;&nbsp;<i class="fas fa-user-friends fa-fw mr-2"></i>&nbsp;Auxiliares
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('caja.venta.index')): ?>
                        <li>
                            <a href="<?php echo e(route('caja.venta.indexAfter')); ?>">
                                &nbsp;&nbsp;<i class="fa-solid fa-layer-group fa-fw mr-2"></i>&nbsp;Cajas Ventas
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asiento.automatico.index')): ?>
                        <li>
                            <a href="<?php echo e(route('asiento.automatico.indexAfter')); ?>">
                                &nbsp;&nbsp;<i class="fa-solid fa-layer-group fa-fw mr-2"></i>&nbsp;Asientos Automaticos
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mesas.index')): ?>
            <li>
                <a href="<?php echo e(route('mesas.indexAfter')); ?>">
                    <i class="fas fa-utensils fa-fw mr-1"></i>&nbsp;Mesas
                </a>
            </li>
        <?php endif; ?>
        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sucursal.index')): ?>
            <li>
                <a href="<?php echo e(route('sucursal.indexAfter')); ?>">
                    <i class="fa-solid fa-house-damage fa-fw mr-1"></i>&nbsp;Sucursales
                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('productos.index')): ?>
            <li>
                <a href="<?php echo e(route('productos.indexAfter')); ?>">
                    <i class="fas fa-wine-glass-alt fa-fw mr-1"></i>&nbsp;Productos
                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['cargos.index','personal.index'])): ?>
            <li>
                <a href="" data-toggle="collapse" data-target="#dashboard_rrhh" class="active collapsed" aria-expanded="false">
                    <i class="fa-solid fa-gift fa-fw mr-1"></i>&nbsp;Recursos Humanos
                    <span class="fa fa-arrow-circle-left float-right"></span>
                </a>
                <ul class="sub-menu collapse" id="dashboard_rrhh">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cargos.index')): ?>
                        <li>
                            <a href="<?php echo e(route('cargos.indexAfter')); ?>">
                                &nbsp;&nbsp;<i class="fa-solid fa-diagram-project fa-fw mr-2"></i>&nbsp;Cargos
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('personal.index')): ?>
                        <li>
                            <a href="<?php echo e(route('personal.indexAfter')); ?>">
                                &nbsp;&nbsp;<i class="fas fa-user-friends fa-fw mr-2"></i>&nbsp;Personal
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
    </ul>
</div>
<?php /**PATH D:\SistemaGanaderia\pi-agropec\resources\views/layouts/partials/menu.blade.php ENDPATH**/ ?>