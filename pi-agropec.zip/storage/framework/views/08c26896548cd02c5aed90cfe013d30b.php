<form action="#" method="get" id="form">
    <input type="hidden" name="empresa_id" value="<?php echo e($empresa->id); ?>" id="empresa_id">
    <div class="form-group row">
        <div class="col-md-2 px-0 pr-1">
            <input type="text" name="producto_id" placeholder="--Producto_id--" value="<?php echo e(request('producto_id')); ?>" class="form-control font-roboto-12 intro" onkeypress="return valideNumberSinDecimal(event);">
        </div>
        <div class="col-md-4 pr-1 pl-1">
            <input type="text" name="nombre" placeholder="--Producto--" value="<?php echo e(request('nombre')); ?>" class="form-control font-roboto-12 intro" oninput="this.value = this.value.toUpperCase()">
        </div>
        <div class="col-md-4 pr-1 pl-1">
            <input type="text" name="nombre_factura" placeholder="--Producto Factura--" value="<?php echo e(request('nombre_factura')); ?>" class="form-control font-roboto-12 intro" oninput="this.value = this.value.toUpperCase()">
        </div>
        <div class="col-md-2 px-0 pl-1">
            <input type="text" name="codigo" placeholder="--Codigo--" value="<?php echo e(request('codigo')); ?>" class="form-control font-roboto-12 intro" oninput="this.value = this.value.toUpperCase()">
        </div>
    </div>
    <div class="form-group row">
        <div class="col-md-2 px-0 pr-1">
            <input type="text" name="unidad_id" placeholder="--Unidad--" value="<?php echo e(request('unidad_id')); ?>" class="form-control font-roboto-12 intro" oninput="this.value = this.value.toUpperCase()">
        </div>
        <div class="col-md-3 pr-1 pl-1">
            <select name="categoria_master_id" id="categoria_master_id" class="form-control select2">
                <option value="">-</option>
                <?php $__currentLoopData = $categorias_master; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($index); ?>" <?php if(request('categoria_master_id') == $index): ?> selected <?php endif; ?> ><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3 pr-1 pl-1">
            <select name="categoria_id" id="categoria_id" class="form-control select2">
                <option value="">-</option>
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($index); ?>" <?php if(request('categoria_id') == $index): ?> selected <?php endif; ?> ><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-2 pr-1 pl-1">
            <select name="tipo" id="tipo" class="form-control select2">
                <option value="">-</option>
                <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($index); ?>" <?php if(request('tipo') == $index): ?> selected <?php endif; ?> ><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-2 px-0 pl-1">
            <select name="estado" id="estado" class="form-control select2">
                <option value="">-</option>
                <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($index); ?>" <?php if(request('estado') == $index): ?> selected <?php endif; ?> ><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
</form><?php /**PATH D:\SistemaVentas\ventas\resources\views/productos/partials/search.blade.php ENDPATH**/ ?>