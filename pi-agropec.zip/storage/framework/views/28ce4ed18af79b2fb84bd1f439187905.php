<div class="form-group row">
    <div class="col-md-12">
        <table class="table display responsive table-striped">
            <thead>
                <tr class="font-roboto-12">
                    <td class="text-left p-1"><b>COD. ING.</b></td>
                    <td class="text-left p-1"><b>INGRESO</b></td>
                    <td class="text-left p-1"><b>COD. RET.</b></td>
                    <td class="text-left p-1"><b>CI/RUN</b></td>
                    <td class="text-left p-1"><b>NOMBRES</b></td>
                    <td class="text-center p-1"><b>CARGO</b></td>
                    <td class="text-center p-1"><b>CNTTO.</b></td>
                    <td class="text-center p-1"><b>ESTADO</b></td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['personal.show','personal.modificar','personal.retirar','personal.cargar.contrato'])): ?>
                        <td class="text-center p-1"><b><i class="fas fa-bars"></i></b></td>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $personal_laborales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="font-roboto-12">
                        <?php
                            $contratos = App\Models\PersonalContrato::where('personal_id',$datos->personal_id)->get();
                        ?>
                        <td class="text-left p-1" style="vertical-align: middle;"><?php echo e($datos->codigo_ingreso); ?></td>
                        <td  class="text-left p-1" style="vertical-align: middle;">
                            <?php $__currentLoopData = $contratos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($contrato->tipo .': ' . \Carbon\Carbon::parse($contrato->fecha_ingreso)->format('d/m/Y')); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td class="text-left p-1">
                            <?php $__currentLoopData = $contratos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($contrato->tipo .': ' . $contrato->codigo_retiro); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td class="text-left p-1" style="vertical-align: middle;"><?php echo e($datos->personal->ci_run); ?></td>
                        <td class="text-left p-1" style="vertical-align: middle;"><?php echo e($datos->personal->full_name); ?></td>
                        <td class="text-center p-1" style="vertical-align: middle;"><?php echo e($datos->cargo->nombre); ?></td>
                        <td class="text-center p-1" style="vertical-align: middle;">
                            <?php if($datos->file_contrato != null): ?>
                                <a href="<?php echo e(asset($datos->file_contrato)); ?>" target="_blank">
                                    <span class="text-danger"><i class="fas fa-lg fa-file-pdf"></i></span>
                                </a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td class="text-center p-1" style="vertical-align: middle;">
                            <span class="badge-with-padding <?php if($datos->status == "HABILITADO"): ?> badge badge-success <?php else: ?> badge badge-danger <?php endif; ?>">
                                <?php echo e($datos->status); ?>

                            </span>
                        </td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['personal.show','personal.modificar','personal.retirar','personal.cargar.contrato'])): ?>
                            <td class="text-center p-1" style="vertical-align: middle;">
                                <select id="<?php echo e($datos->id); ?>" onchange="redireccionar(this.id);" class="form-control form-control-sm select2-container">
                                    <option value="Seleccionar">Seleccionar</option>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('personal.show')): ?>
                                        <option value="Ver">Ir a detalle</option>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('personal.modificar')): ?>
                                        <option value="Editar">Modificar</option>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('personal.retirar')): ?>
                                        <?php if($datos->contrato_fiscal): ?>
                                            <option value="Retirar Fiscal">Retirar Fiscal</option>
                                        <?php endif; ?>
                                        <?php if($datos->contrato_interno): ?>
                                            <option value="Retirar Interno">Retirar Interno</option>
                                        <?php endif; ?>
                                        <?php if($datos->contrato_servicio): ?>
                                            <option value="Retirar Servicio">Retirar Servicio</option>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('personal.cargar.contrato')): ?>
                                        <?php if(!$datos->file_contrato): ?>
                                            <option value="File Contrato">Subir Contrato</option>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </select>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="d-flex justify-content-end font-roboto-12">
            <?php echo $personal_laborales->links(); ?>

        </div>
    </div>
</div><?php /**PATH D:\SistemaGanaderia\pi-agropec\resources\views/personal/partials/table.blade.php ENDPATH**/ ?>