<div class="form-group row">
    <div class="col-md-12">
        <table id="table-precios" class="table display responsive table-striped hover-orange">
            <thead>
                <tr class="font-roboto-12">
                    <td class="text-center p-1"><b>USUARIO</b></td>
                    <td class="text-center p-1"><b>CARGO</b></td>
                    <td class="text-center p-1"><b>COMPROBANTE</b></td>
                    <td class="text-center p-1"><b>TIPO CAMBIO</b></td>
                    <td class="text-center p-1"><b>GESTION</b></td>
                    <td class="text-center p-1"><b>ESTADO</b></td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['balance.apertura.f.editar','comprobantef.editar'])): ?>
                        <td class="text-center p-1" style="vertical-align: bottom;"><b><i class="fas fa-bars"></i></b></td>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $balances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="font-roboto-11">
                        <td class="text-center p-1"><?php echo e($datos->user->username); ?></td>
                        <td class="text-center p-1"><?php echo e($datos->cargo != null ? $datos->cargo->nombre : '#'); ?></td>
                        <td class="text-center p-1"><?php echo e($datos->comprobantef->nro_comprobante); ?></td>
                        <td class="text-center p-1"><?php echo e($datos->tipo_cambio != null ? number_format($datos->tipo_cambio->dolar_oficial,2,'.',',') : '-'); ?></td>
                        <td class="text-center p-1"><?php echo e($datos->gestion); ?></td>
                        <td class="text-center p-1" width="150px">
                            <span class="badge-with-padding
                                <?php if($datos->status == "PENDIENTE"): ?>
                                    badge badge-secondary
                                <?php else: ?>
                                    <?php if($datos->status == "ANULADO"): ?>
                                        badge badge-danger
                                    <?php else: ?>
                                        badge badge-success text-white
                                    <?php endif; ?>
                                <?php endif; ?>">
                                <?php echo e($datos->status); ?>

                            </span>
                        </td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['balance.apertura.f.editar','comprobantef.editar'])): ?>
                            <td class="text-center p-1">
                                <span class="tts:left tts-slideIn tts-custom" aria-label="Ir a detalle" style="cursor: pointer;">
                                    <a href="<?php echo e(route('comprobantef.editar',$datos->comprobantef_id)); ?>" class="badge-with-padding badge badge-warning text-white">
                                        <i class="fa-solid fa-bars-staggered fa-fw"></i>
                                    </a>
                                </span>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH D:\SistemaVentas\ventas\resources\views/balance_apertura_f/partials/table.blade.php ENDPATH**/ ?>