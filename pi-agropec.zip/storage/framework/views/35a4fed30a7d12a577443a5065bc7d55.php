<div class="form-group row">
    <div class="col-md-12">
        <table class="table display responsive table-striped hover-orange">
            <thead>
                <tr class="font-roboto-12">
                    <td class="text-center p-1"><b>COD.</b></td>
                    <td class="text-center p-1"><b>PAIS</b></td>
                    <td class="text-center p-1"><b>INICIO</b></td>
                    <td class="text-left p-1"><b>RAZON SOCIAL</b></td>
                    <td class="text-left p-1"><b>NOMBRE</b></td>
                    <td class="text-left p-1"><b>TELEFONO</b></td>
                    <td class="text-left p-1"><b>NIT</b></td>
                    <td class="text-center p-1"><b>ESTADO</b></td>
                    <td class="text-center p-1"><b><i class="fas fa-bars"></i></b></td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="font-roboto-12">
                        <td class="text-center p-1"><?php echo e($datos->id); ?></td>
                        <td class="text-center p-1"><?php echo e($datos->pais); ?></td>
                        <td class="text-center p-1"><?php echo e($datos->fecha_i); ?></td>
                        <td class="text-left p-1"><?php echo e($datos->razon_social); ?></td>
                        <td class="text-left p-1"><?php echo e($datos->nombre); ?></td>
                        <td class="text-left p-1"><?php echo e($datos->telefono); ?></td>
                        <td class="text-left p-1"><?php echo e($datos->nit); ?></td>
                        <td class="text-center p-1"><?php echo e($datos->status); ?></td>
                        <td class="text-center p-1">
                            <span class="tts:left tts-slideIn tts-custom" aria-label="Ir empresas" style="cursor: pointer;">
                                <a href="<?php echo e(route('empresas.index',$datos->id)); ?>" class="badge-with-padding badge badge-primary">
                                    <i class="fas fa-list fa-fw"></i>
                                </a>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr class="font-roboto-12">
                    <td colspan="12">
                        <?php echo e($clientes->appends(Request::all())->links()); ?>

                        <p class="text-muted">Mostrando
                            <strong><?php echo e($clientes->count()); ?></strong> registros de
                            <strong><?php echo e($clientes->total()); ?></strong> totales
                        </p>
                    </td>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
<?php /**PATH D:\SistemaVentas\ventas\resources\views/clientes/partials/table.blade.php ENDPATH**/ ?>