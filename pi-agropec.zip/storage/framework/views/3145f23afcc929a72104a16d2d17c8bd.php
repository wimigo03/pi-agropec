<div class="form-group row abs-center">
    <div class="col-md-8">
        <table id="table-precios" class="table display responsive table-striped hover-orange">
            <thead>
                <tr class="font-roboto-12">
                    <td class="text-left p-1"><b>TIPO</b></td>
                    <td class="text-left p-1"><b>DETALLE</b></td>
                    <td class="text-center p-1"><b>ESTADO</b></td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['configuracion.show'])): ?>
                        <td class="text-center p-1"><b><i class="fas fa-bars"></i></b></td>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $configuraciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="font-roboto-11">
                        <td class="text-left p-1"><?php echo e($datos->tipos); ?></td>
                        <td class="text-left p-1"><?php echo e($datos->detalle); ?></td>
                        <td class="text-center p-1" width="150px">
                            <span class="badge-with-padding
                                <?php if($datos->status == "PENDIENTE"): ?>
                                    badge badge-secondary
                                <?php else: ?>
                                    badge badge-success
                                <?php endif; ?>">
                                <?php echo e($datos->status); ?>

                            </span>
                        </td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['configuracion.show'])): ?>
                            <td class="text-center p-1">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('configuracion.show')): ?>
                                    <span class="tts:left tts-slideIn tts-custom" aria-label="Ir a configuracion" style="cursor: pointer;">
                                        <a href="<?php echo e(route('configuracion.show',$datos->id)); ?>" class="badge-with-padding badge badge-info text-white">
                                            <i class="fa-solid fa-bars-staggered fa-fw"></i>
                                        </a>
                                    </span>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="row font-roboto-12">
            <div class="col-md-6">
                <p class="text- muted">Mostrando
                    <strong><?php echo e($configuraciones->count()); ?></strong> registros de
                    <strong><?php echo e($configuraciones->total()); ?></strong> totales
                </p>
            </div>
            <div class="col-md-6">
                <div class="d-flex justify-content-end">
                    <?php echo e($configuraciones->appends(Request::all())->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\SistemaVentas\ventas\resources\views/configuracion/partials/table.blade.php ENDPATH**/ ?>