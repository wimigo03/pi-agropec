<!DOCTYPE html>

<?php $__env->startSection('content'); ?>
    <div class="form-group row">
        <div class="col-md-12">
            <div class="card-header header">
                <div class="row">
                    <div class="col-md-10 font-roboto-17" style="display: flex; align-items: flex-end;">
                        <span class="btn btn-sm btn-outline-dark font-roboto-12" id="toggleSubMenu" style="cursor: pointer;">
                            <i class="fas fa-address-card fa-fw fa-beat"></i>
                        </span>&nbsp;
                        <b><?php echo e($cliente->nombre); ?> - MODIFICAR DATOS DE LA EMPRESA <?php echo e($empresa_cliente->nombre_comercial); ?></b>
                    </div>
                    <div class="col-md-2">
                        &nbsp;
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('empresas.partials.form-editar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="form-group row">
        <div class="col-md-12 text-right">
            <button class="btn btn-outline-primary font-verdana" type="button" onclick="procesar();">
                <i class="fas fa-paper-plane"></i>&nbsp;Actualizar
            </button>
            <button class="btn btn-outline-danger font-verdana" type="button" onclick="cancelar();">
                &nbsp;<i class="fas fa-times"></i>&nbsp;Cancelar
            </button>
            <i class="fa fa-spinner custom-spinner fa-spin fa-lg fa-fw spinner-btn" style="display: none;"></i>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <?php echo $__env->make('layouts.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ready(function() {
            $('.select2').select2({
                theme: "bootstrap4",
                placeholder: "--Seleccionar--",
                width: '100%'
            });
        });

        var Modal = function(mensaje){
            $("#modal-alert .modal-body").html(mensaje);
            $('#modal-alert').modal({keyboard: false});
        }

        function agregar(){
            if(!validarModulos()){
                return false;
            }
            if(!validarRepetidos()){
                return false;
            }
            cargar();
        }

        function validarHeader(){
            if($("#nombre_comercial").val() == ""){
                Modal("El [NOMBRE COMERCIAL] es un dato obligatorio.");
                return false;
            }
            if($("#direccion").val() == ""){
                Modal("La [DIRECCION] es un dato obligatorio.");
                return false;
            }
            if($("#alias").val() == ""){
                Modal("el [ALIAS] es un dato obligatorio.");
                return false;
            }
            return true;
        }

        function validarModulos(){
            if($("#modulo_id >option:selected").val() == ""){
                Modal("Se debe seleccionar un [MODULO] para continuar.");
                return false;
            }
            return true;
        }

        function validarRepetidos(){
            var modulos = $("#detalle_tabla tbody tr");
            if(modulos.length > 0){
                var modulo = $("#modulo_id >option:selected").val();
                for(var i = 0;i < modulos.length;i++){
                    var tr = modulos[i];
                    var modulo_id = $(tr).find(".modulo_id").val();
                    if(modulo == modulo_id){
                        Modal("El modulo seleccionado ya se encuentra en la lista.");
                        return false;
                    }
                }
            }
            return true;
        }

        function cargar(){
            var modulo_id = $("#modulo_id >option:selected").val();
            var modulo = $("#modulo_id option:selected").text();
            var fila = "<tr class='font-roboto-11'>"+
                            "<td class='text-justify p-1'>"+
                                "<input type='hidden' class='modulo_id' name='modulo_id[]' value='" + modulo_id + "'>" + modulo +
                            "</td>"+
                            "<td class='text-center p-1'>"+
                                "HABILITADO" +
                            "</td>"+
                            "<td class='text-center p-1'>"+
                                "<span class='badge-with-padding badge badge-danger' onclick='eliminarItem(this);'>" +
                                      "<i class='fas fa-trash fa-fw'></i>" +
                                 "</span>" +
                            "</td>"
                        "</tr>";

            $("#detalle_tabla").append(fila);
            $('#modulo_id').val('').trigger('change');
            $("#btn-registro").show();
        }

        function eliminarItem(thiss){
            var tr = $(thiss).parents("tr:eq(0)");
            tr.remove();
        }

        function procesar() {
            if(!validarHeader()){
                return false;
            }
            if(!contarRegistros()){
                return false;
            }
            $('#modal_confirmacion').modal({
                keyboard: false
            })
        }

        function contarRegistros(){
            var modulos = $("#detalle_tabla tbody tr");
            if(modulos.length === 0){
                Modal("Al menos debe tener un modulo configurado.");
                return false;
            }
            return true;
        }

        function confirmar() {
            var url = "<?php echo e(route('empresas.update')); ?>";
            $("#form").attr('action', url);
            $(".btn").hide();
            $(".spinner-btn").show();
            $("#form").submit();
        }

        function cancelar(){
            var id = $("#cliente_id").val();
            var url = "<?php echo e(route('empresas.index',':id')); ?>";
            url = url.replace(':id',id);
            window.location.href = url;
        }

        function valideNumberInteger(evt){
            var code = (evt.which) ? evt.which : evt.keyCode;
            if(code>=48 && code<=57){
                return true;
            }else{
                return false;
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SistemaVentas\ventas\resources\views/empresas/editar.blade.php ENDPATH**/ ?>