<form action="#" method="post" id="form">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="plan_cuenta_auxiliar_id" value="<?php echo e($plan_cuenta_auxiliar->id); ?>">
    <div class="form-group row abs-center">
        <div class="col-md-4 font-roboto-12">
            <label for="nombre" class="d-inline">Nombre Auxiliar</label>
            <input type="text" name="nombre" value="<?php echo e($plan_cuenta_auxiliar->nombre); ?>" id="nombre" class="form-control font-roboto-12" oninput="this.value = this.value.toUpperCase();">
        </div>
    </div>
</form>
<?php /**PATH D:\SistemaVentas\ventas\resources\views/plan_cuentas_auxiliares/partials/form-editar.blade.php ENDPATH**/ ?>