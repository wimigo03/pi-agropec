<!DOCTYPE html>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('roles.partials.form-editar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <?php echo $__env->make('layouts.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ready(function() {
            $('.select2').select2({
                theme: "bootstrap4",
                placeholder: "--Seleccionar--",
                width: '100%'
            });
        });

        function marcarTodo(id) {
            input = document.getElementById(id);
            checks = document.getElementsByClassName(id);
            if (input.value == 0) {
                for (let index = 0; index < checks.length; index++) {
                    checks[index].checked = true;
                }
                input.value = 1;
            }else{
                for (let index = 0; index < checks.length; index++) {
                    checks[index].checked = false;
                }
                input.value = 0;
            }
        }

        $('#modulo_id').change(function() {
            var id = $(this).val();
            search(id);
        });

        function search(){
            var id = $("#empresa_id").val();
            var url = "<?php echo e(route('roles.editar',':id')); ?>";
            $("#form_search").attr('action', url);
            url = url.replace(':id',id);
            window.location.href = url;
            $("#form_search").submit();
        }
        function procesar() {
            var url = "<?php echo e(route('roles.update')); ?>";
            $("#form").attr('action', url);
            $(".btn").hide();
            $(".spinner-btn").show();
            $("#form").submit();
        }

        function cancelar(){
            var id = $("#empresa_id").val();
            var url = "<?php echo e(route('roles.index',':id')); ?>";
            url = url.replace(':id',id);
            window.location.href = url;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SistemaVentas\ventas\resources\views/roles/editar.blade.php ENDPATH**/ ?>