<!DOCTYPE html>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('cargos.partials.form-create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="form-group row">
    <div class="col-md-12 text-right">
        <button class="btn btn-outline-primary font-verdana" type="button" onclick="procesar();">
            <i class="fas fa-paper-plane"></i>&nbsp;Procesar
        </button>
        <button class="btn btn-outline-danger font-verdana" type="button" onclick="cancelar();">
            &nbsp;<i class="fas fa-times"></i>&nbsp;Cancelar
        </button>
        <i class="fa fa-spinner custom-spinner fa-spin fa-lg fa-fw spinner-btn" style="display: none;"></i>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <?php echo $__env->make('layouts.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ready(function() {
            $('.select2').select2({
                theme: "bootstrap4",
                placeholder: "--Seleccionar--",
                width: '100%'
            });

            if($("#tipo >option:selected").val() == "1"){
                $("#cuenta_contable").show();
            }else{
                $("#cuenta_contable").hide();
            }
        });

        $('#tipo').on('change', function() {
            if($("#tipo >option:selected").val() == "1"){
                $("#cuenta_contable").show();
            }else{
                $("#cuenta_contable").hide();
            }
        });

        function procesar() {
            var url = "<?php echo e(route('cargos.store')); ?>";
            $("#form").attr('action', url);
            $(".btn").hide();
            $(".spinner-btn").show();
            $("#form").submit();
        }

        function cancelar(){
            $(".btn").hide();
            $(".spinner-btn").show();
            var id = $("#empresa_id").val();
            var url = "<?php echo e(route('cargos.index',[':id'])); ?>";
            url = url.replace(':id',id);
            window.location.href = url;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SistemaVentas\ventas\resources\views/cargos/create.blade.php ENDPATH**/ ?>