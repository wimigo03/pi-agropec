<div class="form-group row">
    <div class="col-md-12">
        <span class="tts:right tts-slideIn tts-custom" aria-label="Exportar a Excel" style="cursor: pointer;">
            <button class="btn btn-success font-verdana" type="button" onclick="excel();">
                <i class="fa-solid fa-file-excel fa-fw"></i>
            </button>
        </span>
        <span class="tts:right tts-slideIn tts-custom" aria-label="Exportar a Pdf" style="cursor: pointer;">
            <button class="btn btn-danger font-verdana" type="button" onclick="pdf();">
                <i class="fa-solid fa-file-pdf fa-fw"></i>
            </button>
        </span>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-12">
        <table id="table-precios" class="table display responsive table-striped hover-orange">
            <thead>
                <tr class="font-roboto-12">
                    <td class="text-left p-1"><b>CODIGO</b></td>
                    <td class="text-left p-1"><b>CUENTA</b></td>
                    <td class="text-center p-1">&nbsp;</td>
                    <td class="text-center p-1">&nbsp;</td>
                    <td class="text-center p-1">&nbsp;</td>
                    <td class="text-center p-1">&nbsp;</td>
                    <td class="text-center p-1">&nbsp;</td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $ingresos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $nroPuntos = 1;
                        for ($i=0; $i < strlen($ing->codigo); $i++) {
                            if($ing->codigo[$i] == '.'){
                                $nroPuntos++;
                            }
                        }
                        $nroColumna = $nroMaxColumna - $nroPuntos;
                    ?>
                    <tr class="font-roboto-11">
                        <td class="text-justify p-1">
                            <strong>
                                <?php echo e($ing->codigo); ?>

                            </strong>
                        </td>
                        <td class="text-justify p-1">
                            <strong>
                                <?php echo e($ing->nombre); ?>

                            </strong>
                        </td>
                        <?php for($i = 0; $i < $nroColumna; $i++): ?>
                            <td></td>
                        <?php endfor; ?>
                        <td class="text-right p-1">
                            <?php echo e(number_format($totales[$ing->id],2,'.',',')); ?>

                        </td>
                        <?php
                            $nroColumna = $nroMaxColumna - $nroColumna -1;
                        ?>
                        <?php for($i = 0; $i < $nroColumna; $i++): ?>
                            <td></td>
                        <?php endfor; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $costos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $costo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $nroPuntos = 1;
                        for ($i=0; $i < strlen($costo->codigo); $i++) {
                            if($costo->codigo[$i] == '.'){
                                $nroPuntos++;
                            }
                        }
                        $nroColumna = $nroMaxColumna - $nroPuntos;
                    ?>
                    <tr class="font-roboto-11">
                        <td class="text-justify p-1">
                            <strong>
                                <?php echo e($costo->codigo); ?>

                            </strong>
                        </td>
                        <td class="text-justify p-1">
                            <strong>
                                <?php echo e($costo->nombre); ?>

                            </strong>
                        </td>
                        <?php for($i = 0; $i < $nroColumna; $i++): ?>
                            <td></td>
                        <?php endfor; ?>
                        <td class="text-right p-1">
                            <?php echo e(number_format($totales[$costo->id],2,'.',',')); ?>

                        </td>
                        <?php
                            $nroColumna = $nroMaxColumna - $nroColumna - 1;
                        ?>
                        <?php for($i = 0; $i < $nroColumna; $i++): ?>
                            <td></td>
                        <?php endfor; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $gastos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $nroPuntos = 1;
                        for ($i=0; $i < strlen($gasto->codigo); $i++) {
                            if($gasto->codigo[$i] == '.'){
                                $nroPuntos++;
                            }
                        }
                        $nroColumna = $nroMaxColumna - $nroPuntos;
                    ?>
                    <tr class="font-roboto-11">
                        <td class="text-justify p-1">
                            <strong>
                                <?php echo e($gasto->codigo); ?>

                            </strong>
                        </td>
                        <td class="text-justify p-1">
                            <strong>
                                <?php echo e($gasto->nombre); ?>

                            </strong>
                        </td>
                        <?php for($i = 0; $i < $nroColumna; $i++): ?>
                            <td></td>
                        <?php endfor; ?>
                        <td class="text-right p-1">
                            <?php echo e(number_format($totales[$gasto->id],2,'.',',')); ?>

                        </td>
                        <?php
                            $nroColumna = $nroMaxColumna - $nroColumna - 1;
                        ?>
                        <?php for($i = 0; $i < $nroColumna; $i++): ?>
                            <td></td>
                        <?php endfor; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot class="font-roboto-11">
                <td class="text-right p-1" colspan="6" ><strong>TOTAL</strong></td>
                <td class="text-right p-1"><strong><?php echo e(number_format($total,2,'.',',')); ?></strong></td>
            </tfoot>
        </table>
    </div>
</div>
<?php /**PATH D:\SistemaVentas\ventas\resources\views/balance_general_f/partials/table.blade.php ENDPATH**/ ?>