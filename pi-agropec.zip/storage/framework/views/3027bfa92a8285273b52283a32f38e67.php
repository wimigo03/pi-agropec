<form action="#" method="get" id="form">
    <input type="hidden" name="empresa_id" value="<?php echo e($empresa->id); ?>" id="empresa_id">
    <div class="form-group row">
        <div class="col-md-2 px-0 pr-1">
            <input type="text" name="codigo_ingreso" placeholder="--Codigo Ingreso--" value="<?php echo e(request('codigo_ingreso')); ?>" class="form-control font-roboto-12 intro" oninput="this.value = this.value.toUpperCase()">
        </div>
        <div class="col-md-2 pr-1 pl-1">
            <input type="text" name="codigo_retiro" placeholder="--Codigo Retiro--" value="<?php echo e(request('codigo_retiro')); ?>" class="form-control font-roboto-12 intro" oninput="this.value = this.value.toUpperCase()">
        </div>
        <div class="col-md-3 pr-1 pl-1">
            <input type="text" name="ci_run" placeholder="--Ci/Run--" value="<?php echo e(request('ci_run')); ?>" class="form-control font-roboto-12 intro" oninput="this.value = this.value.toUpperCase()">
        </div>
        <div class="col-md-2 pr-1 pl-1">
            <input type="text" name="primer_nombre" placeholder="--Primer Nombre--" value="<?php echo e(request('primer_nombre')); ?>" class="form-control font-roboto-12 intro" oninput="this.value = this.value.toUpperCase()">
        </div>
        <div class="col-md-3 px-0 pl-1">
            <input type="text" name="apellido_paterno" placeholder="--Apellido Paterno--" value="<?php echo e(request('apellido_paterno')); ?>" class="form-control font-roboto-12 intro" oninput="this.value = this.value.toUpperCase()">
        </div>
    </div>
    <div class="form-group row">
        <div class="col-md-3 px-0 pr-1">
            <input type="text" name="apellido_materno" placeholder="--Apellido Materno--" value="<?php echo e(request('apellido_materno')); ?>" class="form-control font-roboto-12 intro" oninput="this.value = this.value.toUpperCase()">
        </div>
        <div class="col-md-5 pr-1 pl-1">
            <select name="cargo_id" id="cargo_id" class="form-control select2">
                <option value="">-</option>
                <?php $__currentLoopData = $cargos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($index); ?>" <?php if(request('cargo_id') == $index): ?> selected <?php endif; ?> ><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-2 pr-1 pl-1">
            <select name="file_contrato" id="file_contrato" class="form-control select2">
                <option value="">-</option>
                <option value="1" <?php if(request('file_contrato') == '1'): ?> selected <?php endif; ?> >CON CONTRATO</option>
                <option value="2" <?php if(request('file_contrato') == '2'): ?> selected <?php endif; ?> >SIN CONTRATO</option>
            </select>
        </div>
        <div class="col-md-2 px-0 pl-1">
            <select name="estado" id="estado" class="form-control select2">
                <option value="">-</option>
                <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($index); ?>" <?php if(request('estado') == $index): ?> selected <?php endif; ?> ><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
</form>
<?php /**PATH D:\SistemaVentas\ventas\resources\views/personal/partials/search.blade.php ENDPATH**/ ?>