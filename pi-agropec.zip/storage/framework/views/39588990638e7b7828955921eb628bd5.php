<div class="form-group row">
    <div class="col-md-12">
        <table class="table display responsive table-striped hover-orange">
            <thead>
                <tr class="font-roboto-12 bg-warning text-white">
                    <td class="text-left p-1"><b>FECHA</b></td>
                    <td class="text-left p-1"><b>NRO. COMPROBANTE</b></td>
                    <td class="text-left p-1"><b>CONCEPTO</b></td>
                    <td class="text-center p-1"><b>EMPRESA</b></td>
                    <td class="text-right p-1"><b>MONTO</b></td>
                    <td class="text-center p-1"><b>ESTADO</b></td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['comprobante.editar'])): ?>
                        <td class="text-center p-1"><b><i class="fas fa-bars"></i></b></td>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $comprobantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="font-roboto-12">
                        <td class="text-left p-1"><?php echo e(\Carbon\Carbon::parse($datos->fecha)->format('d/m/Y')); ?></td>
                        <td class="text-left p-1"><?php echo e($datos->nro_comprobante); ?></td>
                        <td class="text-left p-1"><?php echo e($datos->concepto); ?></td>
                        <td class="text-center p-1"><?php echo e($datos->empresa->alias); ?></td>
                        <td class="text-right p-1"><?php echo e(number_format($datos->monto,2,'.',',')); ?></td>
                        <td class="text-center p-1">
                            <span class="badge-with-padding
                                <?php if($datos->status == "PENDIENTE"): ?>
                                    badge badge-secondary
                                <?php else: ?>
                                    <?php if($datos->status == "APROBADO"): ?>
                                        badge badge-success
                                    <?php else: ?>
                                        badge badge-danger
                                    <?php endif; ?>
                                <?php endif; ?>">
                                <?php echo e($datos->status); ?>

                            </span>
                        </td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['comprobante.editar'])): ?>
                            <td class="text-center p-1">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('comprobantef.pdf')): ?>
                                    <span class="tts:left tts-slideIn tts-custom" aria-label="Pdf" style="cursor: pointer;">
                                        <a href="<?php echo e(route('comprobantef.pdf',$datos->id)); ?>" class="badge-with-padding badge badge-danger" target="_blank">
                                            <i class="fa-solid fa-file-pdf fa-fw"></i>
                                        </a>
                                    </span>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('comprobantef.show')): ?>
                                    <span class="tts:left tts-slideIn tts-custom" aria-label="Ir a detalle" style="cursor: pointer;">
                                        <a href="<?php echo e(route('comprobantef.show',$datos->id)); ?>" class="badge-with-padding badge badge-primary">
                                            <i class="fa-solid fa-list-check fa-fw"></i>
                                        </a>
                                    </span>
                                <?php endif; ?>
                                <?php if($datos->estado == '1'): ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('comprobantef.editar')): ?>
                                        <span class="tts:left tts-slideIn tts-custom" aria-label="Modificar" style="cursor: pointer;">
                                            <a href="<?php echo e(route('comprobantef.editar',$datos->id)); ?>" class="badge-with-padding badge badge-warning">
                                                <i class="fas fa-edit fa-fw"></i>
                                            </a>
                                        </span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="tts:left tts-slideIn tts-custom" aria-label="Modificar No Permitido" style="cursor: pointer;">
                                        <a href="#" class="badge-with-padding badge badge-secondary">
                                            <i class="fas fa-edit fa-fw"></i>
                                        </a>
                                    </span>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="row font-roboto-12">
            <div class="col-md-6">
                <p class="text- muted">Mostrando
                    <strong><?php echo e($comprobantes->count()); ?></strong> registros de
                    <strong><?php echo e($comprobantes->total()); ?></strong> totales
                </p>
            </div>
            <div class="col-md-6">
                <div class="d-flex justify-content-end">
                    <?php echo e($comprobantes->appends(Request::all())->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\SistemaVentas\ventas\resources\views/comprobantesf/partials/table.blade.php ENDPATH**/ ?>