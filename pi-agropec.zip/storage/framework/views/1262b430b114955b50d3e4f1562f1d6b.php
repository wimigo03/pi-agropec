<div class="form-group row abs-center">
    <div class="col-md-8">
        <table class="table display responsive table-striped hover-orange">
            <thead>
                <tr class="font-roboto-12 bg-secondary text-white">
                    <td class="text-center p-1"><b>MODULO</b></td>
                    <td class="text-center p-1"><b>NOMBRE DEL ASIENTO AUTOMATICO</b></td>
                    <td class="text-center p-1"><b>ESTADO</b></td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['asiento.automatico.show','asiento.automatico.editar'])): ?>
                        <td class="text-center p-1"><b><i class="fas fa-bars"></i></b></td>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $asientos_automaticos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="font-roboto-12">
                        <td class="text-center p-1"><?php echo e($datos->modulo->nombre); ?></td>
                        <td class="text-left p-1"><?php echo e($datos->nombre); ?></td>
                        <td class="text-center p-1">
                            <span class="<?php echo e($datos->color_badge_status); ?>">
                                <?php echo e($datos->status); ?>

                            </span>
                        </td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['asiento.automatico.editar','asiento.automatico.habilitar'])): ?>
                            <td class="text-center p-1">
                                <div class="d-flex justify-content-center">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asiento.automatico.show')): ?>
                                        <span class="tts:left tts-slideIn tts-custom" aria-label="Ir a detalle" style="cursor: pointer;">
                                            <a href="<?php echo e(route('asiento.automatico.show',$datos->id)); ?>" class="badge-with-padding badge badge-primary">
                                                <i class="fas fa-list fa-fw"></i>
                                            </a>
                                        </span>
                                    <?php endif; ?>
                                    &nbsp;
                                    <?php if($datos->estado == '1'): ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asiento.automatico.editar')): ?>
                                            <span class="tts:left tts-slideIn tts-custom" aria-label="Modificar" style="cursor: pointer;">
                                                <a href="<?php echo e(route('asiento.automatico.editar',$datos->id)); ?>" class="badge-with-padding badge badge-warning">
                                                    <i class="fas fa-edit fa-fw"></i>
                                                </a>
                                            </span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="tts:left tts-slideIn tts-custom" aria-label="Modificar No Permitido" style="cursor: pointer;">
                                            <a href="#" class="badge-with-padding badge badge-secondary">
                                                <i class="fas fa-edit fa-fw"></i>
                                            </a>
                                        </span>
                                    <?php endif; ?>
                                    &nbsp;
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asiento.automatico.habilitar')): ?>
                                        <?php if($datos->status == "HABILITADO"): ?>
                                            <span class="tts:left tts-slideIn tts-custom" aria-label="Deshabilitar" style="cursor: pointer;">
                                                <a href="<?php echo e(route('asiento.automatico.deshabilitar',$datos->id)); ?>" class="badge-with-padding badge badge-danger">
                                                    <i class="fas fa-arrow-alt-circle-down fa-fw"></i>
                                                </a>
                                            </span>
                                        <?php else: ?>
                                            <span class="tts:left tts-slideIn tts-custom" aria-label="Habilitar" style="cursor: pointer;">
                                                <a href="<?php echo e(route('asiento.automatico.habilitar',$datos->id)); ?>" class="badge-with-padding badge badge-success">
                                                    <i class="fas fa-arrow-alt-circle-up fa-fw"></i>
                                                </a>
                                            </span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="row font-roboto-12">
            <div class="col-md-6">
                <p class="text- muted">Mostrando
                    <strong><?php echo e($asientos_automaticos->count()); ?></strong> registros de
                    <strong><?php echo e($asientos_automaticos->total()); ?></strong> totales
                </p>
            </div>
            <div class="col-md-6">
                <div class="d-flex justify-content-end">
                    <?php echo e($asientos_automaticos->appends(Request::all())->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\SistemaVentas\ventas\resources\views/asientos_automaticos/partials/table.blade.php ENDPATH**/ ?>