<div class="form-group row">
    <div class="col-md-12">
        <table class="table display responsive table-striped hover-orange">
            <thead>
                <tr class="font-roboto-11">
                    <td class="text-left p-1"><b>ID</b></td>
                    <td class="text-left p-1"><b>MODULO</b></td>
                    <td class="text-left p-1"><b>TITULO</b></td>
                    <td class="text-left p-1"><b>NOMBRE</b></td>
                    <td class="text-left p-1"><b>DESCRIPCION</b></td>
                    <td class="text-center p-1"><b><i class="fas fa-bars"></i></b></td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="font-roboto-11">
                        <td class="text-left p-1"><?php echo e($datos->id); ?></td>
                        <td class="text-left p-1"><?php echo e($datos->modulo->nombre); ?></td>
                        <td class="text-left p-1"><?php echo e($datos->title); ?></td>
                        <td class="text-left p-1"><?php echo e($datos->name); ?></td>
                        <td class="text-left p-1"><?php echo e($datos->description); ?></td>
                        <td class="text-center p-1">
                            <span class="tts:left tts-slideIn tts-custom" aria-label="Modificar" style="cursor: pointer;">
                                <a href="<?php echo e(route('permissions.editar',$datos->id)); ?>" class="badge-with-padding badge badge-warning">
                                    <i class="fas fa-edit fa-fw"></i>
                                </a>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="row font-roboto-12">
            <div class="col-md-6">
                <p class="text- muted">Mostrando
                    <strong><?php echo e($permissions->count()); ?></strong> registros de
                    <strong><?php echo e($permissions->total()); ?></strong> totales
                </p>
            </div>
            <div class="col-md-6">
                <div class="d-flex justify-content-end">
                    <?php echo e($permissions->appends(Request::all())->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH D:\SistemaVentas\ventas\resources\views/permissions/partials/table.blade.php ENDPATH**/ ?>