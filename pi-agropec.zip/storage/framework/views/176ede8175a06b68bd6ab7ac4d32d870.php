<div class="form-group row font-roboto-12" id="subMenuPrecioVentas">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('categorias.index')): ?>
        <div class="col-md-3 sub-botones-producto">
            <a href="<?php echo e(route('categorias.index',['empresa_id' => $empresa->id, 'status_platos' => '[]', 'status_insumos' => '[]'])); ?>" class="btn btn-outline-secondary btn-block font-roboto-12">
                <i class="fas fa-poll-h fa-fw"></i>&nbsp;Categorias
            </a>
        </div>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('unidades.index')): ?>
        <div class="col-md-2 sub-botones-producto">
            <a href="<?php echo e(route('unidades.index',['empresa_id' => $empresa->id])); ?>" class="btn btn-outline-secondary btn-block font-roboto-12">
                <i class="fas fa-balance-scale fa-fw"></i>&nbsp;Unidades
            </a>
        </div>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('productos.index')): ?>
        <div class="col-md-3 sub-botones-producto">
            <a href="<?php echo e(route('productos.index',['empresa_id' => $empresa->id])); ?>" class="btn btn-outline-secondary btn-block font-roboto-12">
                <i class="fas fa-wine-glass-alt fa-fw"></i>&nbsp;Productos
            </a>
        </div>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tipo.precios.index')): ?>
        <div class="col-md-2 sub-botones-producto">
            <a href="<?php echo e(route('tipo.precios.index',['empresa_id' => $empresa->id])); ?>" class="btn btn-outline-secondary btn-block font-roboto-12">
                <i class="fas fa-dollar fa-fw"></i>&nbsp;Tipos de Precio
            </a>
        </div>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('precio.productos.index')): ?>
        <div class="col-md-2 sub-botones-producto">
            <a href="<?php echo e(route('precio.productos.index',['empresa_id' => $empresa->id])); ?>" class="btn btn-info btn-block font-roboto-12">
                <i class="fa-solid fa-tag fa-fw fa-beat"></i>&nbsp;Precios
            </a>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH D:\SistemaVentas\ventas\resources\views/precio_productos/partials/menu.blade.php ENDPATH**/ ?>