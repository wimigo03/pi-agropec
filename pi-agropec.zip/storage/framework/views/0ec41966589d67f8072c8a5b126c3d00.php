<!DOCTYPE html>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('permissions.partials.form-create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="form-group row abs-center font-roboto-12">
        <div class="col-md-2 px-0 pr-1">
            <button class="btn btn-block btn-outline-primary font-verdana" type="button" onclick="procesar();">
                <i class="fas fa-paper-plane"></i>&nbsp;Procesar
            </button>
            <i class="fa fa-spinner custom-spinner fa-spin fa-lg fa-fw spinner-btn" style="display: none;"></i>
        </div>
        <div class="col-md-2 pr-1 pl-1">
            <button class="btn btn-block btn-outline-danger font-verdana" type="button" onclick="cancelar();">
                &nbsp;<i class="fas fa-times"></i>&nbsp;Cancelar
            </button>
            <i class="fa fa-spinner custom-spinner fa-spin fa-lg fa-fw spinner-btn" style="display: none;"></i>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <?php echo $__env->make('layouts.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ready(function() {
            $("#form_nuevo_titulo").hide();
            if($("#titulo >option:selected").val() === "_NUEVO_"){
                $("#form_nuevo_titulo").show();
            }else{
                $("#form_nuevo_titulo").hide();
                document.getElementById('nuevo_titulo').value = '';
            }

            $('.select2').select2({
                theme: "bootstrap4",
                placeholder: "--Seleccionar--",
                width: '100%'
            });
        });

        $('#titulo').on('change', function() {
                if($("#titulo >option:selected").val() === "_NUEVO_"){
                    $("#form_nuevo_titulo").show();
                }else{
                    $("#form_nuevo_titulo").hide();
                    document.getElementById('nuevo_titulo').value = '';
                }
            }
        );

        $('.intro').on('keypress', function(event) {
            if (event.which === 13) {
                procesar();
                event.preventDefault();
            }
        });

        function procesar() {
            var url = "<?php echo e(route('permissions.store')); ?>";
            $("#form").attr('action', url);
            $(".btn").hide();
            $(".spinner-btn").show();
            $("#form").submit();
        }

        function cancelar(){
            var id = $("#empresa_id").val();
            var url = "<?php echo e(route('permissions.index',':id')); ?>";
            url = url.replace(':id',id);
            window.location.href = url;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SistemaVentas\ventas\resources\views/permissions/create.blade.php ENDPATH**/ ?>