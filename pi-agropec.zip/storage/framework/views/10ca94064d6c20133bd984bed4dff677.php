<div class="form-group row">
    <div class="col-md-12">
        <table class="table display responsive table-striped hover-orange">
            <thead>
                <tr class="font-roboto-12 bg-secondary text-white">
                    <td class="text-center p-1"><b>SUCURSAL</b></td>
                    <td class="text-center p-1"><b>FECHA</b></td>
                    <td class="text-center p-1"><b>CODIGO</b></td>
                    <td class="text-center p-1"><b>ASIGNADO A</b></td>
                    <td class="text-center p-1"><b>ASIGNADO POR</b></td>
                    <td class="text-center p-1"><b>MONTO</b></td>
                    <td class="text-center p-1"><b>ESTADO</b></td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['caja.venta.show'])): ?>
                        <td class="text-center p-1"><b><i class="fas fa-bars"></i></b></td>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cajas_ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="font-roboto-12">
                        <td class="text-center p-1"><?php echo e($datos->sucursal->nombre); ?></td>
                        <td class="text-center p-1"><?php echo e(\Carbon\Carbon::parse($datos->fecha_registro)->format('d/m/Y')); ?></td>
                        <td class="text-center p-1"><?php echo e($datos->codigo); ?></td>
                        <td class="text-center p-1"><?php echo e(strtoupper($datos->user->username)); ?></td>
                        <td class="text-center p-1"><?php echo e($datos->user_asignado != null ? $datos->user_asignado->username : ''); ?></td>
                        <td class="text-right p-1"><?php echo e(number_format($datos->monto_apertura,2,'.',',')); ?></td>
                        <td class="text-center p-1">
                            <span class="<?php echo e($datos->color_badge_status); ?>">
                                <?php echo e($datos->status); ?>

                            </span>
                        </td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['caja.venta.show'])): ?>
                            <td class="text-center p-1">
                                <div class="d-flex justify-content-center">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('caja.venta.show')): ?>
                                        <span class="tts:left tts-slideIn tts-custom" aria-label="Ir a detalle" style="cursor: pointer;">
                                            <a href="<?php echo e(route('caja.venta.show',$datos->id)); ?>" class="badge-with-padding badge badge-primary">
                                                <i class="fas fa-list fa-fw"></i>
                                            </a>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="row font-roboto-12">
            <div class="col-md-6">
                <p class="text- muted">Mostrando
                    <strong><?php echo e($cajas_ventas->count()); ?></strong> registros de
                    <strong><?php echo e($cajas_ventas->total()); ?></strong> totales
                </p>
            </div>
            <div class="col-md-6">
                <div class="d-flex justify-content-end">
                    <?php echo e($cajas_ventas->appends(Request::all())->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\SistemaVentas\ventas\resources\views/caja_venta/partials/table.blade.php ENDPATH**/ ?>