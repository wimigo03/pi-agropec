<form action="#" method="get" id="form">
    <input type="hidden" value="<?php echo e($cliente->id); ?>" id="cliente_id">
    <div class="form-group row font-roboto-12">
        <div class="col-md-2 px-0 pr-1">
            <input type="text" name="codigo" placeholder="--Codigo--" value="<?php echo e(request('codigo')); ?>" class="form-control font-roboto-12 intro" onkeypress="return valideNumberInteger(event);">
        </div>
        <div class="col-md-5 pr-1 pl-1">
            <input type="text" name="nombre_comercial" placeholder="--Nombre Comercial--" value="<?php echo e(request('nombre_comercial')); ?>" class="form-control font-roboto-12 intro" oninput="this.value = this.value.toUpperCase()">
        </div>
        <div class="col-md-3 pr-1 pl-1">
            <input type="text" name="telefono" placeholder="--Telefono--" value="<?php echo e(request('telefono')); ?>" class="form-control font-roboto-12 intro" onkeypress="return valideNumberInteger(event);">
        </div>
        <div class="col-md-2 px-0 pl-1">
            <select name="estado" id="estado" class="form-control">
                <option value="">-</option>
                <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($index); ?>" <?php if(request('estado') == $index): ?> selected <?php endif; ?> ><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
</form>
<?php /**PATH D:\SistemaVentas\ventas\resources\views/empresas/partials/search.blade.php ENDPATH**/ ?>