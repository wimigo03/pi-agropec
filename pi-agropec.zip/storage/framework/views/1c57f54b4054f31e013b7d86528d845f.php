<table>
    <tr>
        <td colspan="8" align="center">
            <b>BALANCE GENERAL</b>
        </td>
    </tr>
    <tr>
        <td colspan="8" align="center">
            <b>AL <?php echo e($fecha_f); ?></b>
        </td>
    </tr>
</table>
<table>
    <thead>
        <tr>
            <td><b>CODIGO</b></td>
            <td><b>CUENTA</b></td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $ingresos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $nroPuntos = 1;
                for ($i=0; $i < strlen($ing->codigo); $i++) {
                    if($ing->codigo[$i] == '.'){
                        $nroPuntos++;
                    }
                }
                $nroColumna = $nroMaxColumna - $nroPuntos;
            ?>
            <tr>
                <td>
                    <strong>
                        <?php echo e($ing->codigo); ?>

                    </strong>
                </td>
                <td>
                    <strong>
                        <?php echo e($ing->nombre); ?>

                    </strong>
                </td>
                <?php for($i = 0; $i < $nroColumna; $i++): ?>
                    <td></td>
                <?php endfor; ?>
                <td>
                    <?php echo e($totales[$ing->id]); ?>

                </td>
                <?php
                    $nroColumna = $nroMaxColumna - $nroColumna -1;
                ?>
                <?php for($i = 0; $i < $nroColumna; $i++): ?>
                    <td></td>
                <?php endfor; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $costos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $costo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $nroPuntos = 1;
                for ($i=0; $i < strlen($costo->codigo); $i++) {
                    if($costo->codigo[$i] == '.'){
                        $nroPuntos++;
                    }
                }
                $nroColumna = $nroMaxColumna - $nroPuntos;
            ?>
            <tr>
                <td>
                    <strong>
                        <?php echo e($costo->codigo); ?>

                    </strong>
                </td>
                <td>
                    <strong>
                        <?php echo e($costo->nombre); ?>

                    </strong>
                </td>
                <?php for($i = 0; $i < $nroColumna; $i++): ?>
                    <td></td>
                <?php endfor; ?>
                <td>
                    <?php echo e($totales[$costo->id]); ?>

                </td>
                <?php
                    $nroColumna = $nroMaxColumna - $nroColumna - 1;
                ?>
                <?php for($i = 0; $i < $nroColumna; $i++): ?>
                    <td></td>
                <?php endfor; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $gastos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $nroPuntos = 1;
                for ($i=0; $i < strlen($gasto->codigo); $i++) {
                    if($gasto->codigo[$i] == '.'){
                        $nroPuntos++;
                    }
                }
                $nroColumna = $nroMaxColumna - $nroPuntos;
            ?>
            <tr>
                <td>
                    <strong>
                        <?php echo e($gasto->codigo); ?>

                    </strong>
                </td>
                <td>
                    <strong>
                        <?php echo e($gasto->nombre); ?>

                    </strong>
                </td>
                <?php for($i = 0; $i < $nroColumna; $i++): ?>
                    <td></td>
                <?php endfor; ?>
                <td>
                    <?php echo e($totales[$gasto->id]); ?>

                </td>
                <?php
                    $nroColumna = $nroMaxColumna - $nroColumna - 1;
                ?>
                <?php for($i = 0; $i < $nroColumna; $i++): ?>
                    <td></td>
                <?php endfor; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td><b>TOTAL</b></td>
        <td><b><?php echo e($total); ?></b></td>
    </tr>
</table>
<?php /**PATH D:\SistemaVentas\ventas\resources\views/balance_general_f/excel.blade.php ENDPATH**/ ?>