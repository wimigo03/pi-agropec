<div class="form-group row">
    <div class="col-md-12">
        <table class="table display responsive table-striped">
            <thead>
                <tr class="font-roboto-12">
                    <td class="text-left p-1"><b>ID</b></td>
                    <td class="text-left p-1"><b>CODIGO</b></td>
                    <td class="text-left p-1"><b>PRODUCTO</b></td>
                    <td class="text-left p-1"><b>TIPO</b></td>
                    <td class="text-right p-1"><b>PRECIO</b></td>
                    <td class="text-right p-1"><b>% DESC.</b></td>
                    <td class="text-right p-1"><b>P. FINAL</b></td>
                    <td class="text-center p-1"><b>ESTADO</b></td>
                    
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $precios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="font-roboto">
                        <td class="text-left p-1"><?php echo e($datos->id); ?></td>
                        <td class="text-left p-1"><?php echo e($datos->producto->codigo); ?></td>
                        <td class="text-left p-1"><?php echo e($datos->producto->nombre); ?></td>
                        <td class="text-left p-1"><?php echo e($datos->tipo_p->nombre); ?></td>
                        <td class="text-right p-1"><?php echo e($datos->costo); ?></td>
                        <td class="text-right p-1"><?php echo e($datos->p_descuento); ?></td>
                        <td class="text-right p-1"><?php echo e($datos->costo_final); ?></td>
                        <td class="text-center p-1">
                            <span class="badge-with-padding <?php if($datos->status == "HABILITADO"): ?> badge badge-success <?php else: ?> badge badge-danger <?php endif; ?>">
                                <?php echo e($datos->status); ?>

                            </span>
                        </td>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="d-flex justify-content-end font-roboto-12">
            <?php echo $precios->links(); ?>

        </div>
    </div>
</div><?php /**PATH D:\SistemaVentas\ventas\resources\views/precio_ventas/partials/table.blade.php ENDPATH**/ ?>