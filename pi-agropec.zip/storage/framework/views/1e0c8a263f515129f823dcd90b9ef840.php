<form action="#" method="post" id="form">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="cliente_id" value="<?php echo e($empresa->cliente_id); ?>" id="cliente_id">
    <input type="hidden" name="empresa_id" value="<?php echo e($empresa->id); ?>" id="empresa_id">
    <div class="form-group row font-roboto-bg">
        <div class="col-md-4 hiddenContent" id="datos-mesa" style="display: none;">
            x
        </div>
        <div class="col-md-12" id="mapa-mesa">
            <ul class="nav nav-tabs" id="myTabs" role="tablist">
                <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e($key === 0 ? 'active' : ''); ?>" id="tab<?php echo e($key + 1); ?>" data-toggle="tab" href="#content<?php echo e($key + 1); ?>" role="tab" aria-controls="content<?php echo e($key + 1); ?>" aria-selected="<?php echo e($key === 0 ? 'true' : 'false'); ?>" data-zona-id="<?php echo e($zona->id); ?>">
                                <?php echo e($zona->nombre); ?>

                                <input type="hidden" name="zona_id" value="#" id="zona_id">
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="tab-content" id="myTabsContent">
                <br>
                <?php $__currentLoopData = $zonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $zona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tab-pane fade <?php echo e($key === 0 ? 'show active' : ''); ?>" id="content<?php echo e($key + 1); ?>" role="tabpanel" aria-labelledby="tab<?php echo e($key + 1); ?>">
                        <div class="form-group row">
                            <div class="col-md-12">
                                <div id="tablaContainer">
                                    <table class="display table-bordered responsive" id="table-zona">
                                        <?php for($i = 0; $i < $zona->filas; $i++): ?>
                                            <tr class="font-roboto">
                                                <?php for($j = 0; $j < $zona->columnas; $j++): ?>
                                                    <td class="text-center p-1 cell-with-image">
                                                        <span onclick="alternarDatos()" style="cursor: pointer;">
                                                        <?php
                                                            $ocupado = App\Models\Mesa::where('zona_id',$zona->id)->where('fila',$i)->where('columna',$j)->where('estado','3')->first();
                                                        ?>
                                                        <?php if($ocupado != null): ?>
                                                            <div class="imagen-con-texto">
                                                                <img src="/images/mesa-1.png" alt="mesa-1" class="imagen-mesa-1">
                                                                <div class="circulo-texto"></div>
                                                                <span class="texto-sobre-imagen font-roboto"><b><?php echo e($ocupado->numero); ?></b></span>
                                                            </div>
                                                        <?php else: ?>
                                                            <?php if($zona->mesas_habilitadas != 0): ?>
                                                                <span class="tts:down tts-slideIn tts-custom" aria-label="Insertar Mesa" style="cursor: pointer;">
                                                                    <span class="badge-with-padding badge badge-secondary text-white" data-toggle="modal" data-target="#ModalAsignarMesa" style="opacity: 0.5;" onclick="cargarMesas('<?php echo e($i); ?>','<?php echo e($j); ?>');">
                                                                        <i class="fa-solid fa-plus fa-fw"></i>
                                                                    </span>
                                                                </span>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                        </span>
                                                    </td>
                                                <?php endfor; ?>
                                            </tr>
                                        <?php endfor; ?>
                                    </table>
                                </div>
                            </div>
                        </div>           
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</form><?php /**PATH D:\SistemaVentas\ventas\resources\views/mesas/partials/form-setting.blade.php ENDPATH**/ ?>