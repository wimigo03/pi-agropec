<div class="form-group row">
    <div class="col-md-12">
        <table class="table display responsive table-striped hover-orange">
            <thead>
                <tr class="font-roboto-12">
                    <td class="text-center p-1"><b>NOMBRE</b></td>
                    <td class="text-center p-1"><b>ORIGEN</b></td>
                    <td class="text-center p-1"><b>INDENTIFICADOR</b></td>
                    <td class="text-center p-1"><b>TIPO</b></td>
                    <td class="text-center p-1"><b>EST.</b></td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['plan.cuentas.auxiliar.habilitar','plan.cuentas.auxiliar.editar'])): ?>
                        <td class="text-center p-1"><b><i class="fas fa-bars"></i></b></td>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $plan_cuentas_auxiliares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="font-roboto-11">
                        <td class="text-left p-1"><?php echo e($datos->nombre); ?></td>
                        <td class="text-left p-1"><?php echo e($datos->class_name); ?></td>
                        <td class="text-left p-1"><?php echo e($datos->class_name_id); ?></td>
                        <td class="text-center p-1"><?php echo e($datos->tipus); ?></td>
                        <td class="text-center p-1">
                            <span class="badge-with-padding <?php if($datos->status == "HABILITADO"): ?> badge badge-success <?php else: ?> badge badge-danger <?php endif; ?>">
                                &nbsp;<?php echo e($datos->status); ?>&nbsp;
                            </span>
                        </td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['plan.cuentas.auxiliar.habilitar','plan.cuentas.auxiliar.editar'])): ?>
                            <td class="text-center p-1">
                                <?php if($datos->status == "HABILITADO"): ?>
                                    <span class="tts:left tts-slideIn tts-custom" aria-label="Deshabilitar" style="cursor: pointer;">
                                        <a href="<?php echo e(route('plan_cuentas.auxiliar.deshabilitar',$datos->id)); ?>" class="badge-with-padding badge badge-danger">
                                            <i class="fas fa-lg fa-arrow-alt-circle-down"></i>
                                        </a>
                                    </span>
                                <?php else: ?>
                                    <span class="tts:left tts-slideIn tts-custom" aria-label="Habilitar" style="cursor: pointer;">
                                        <a href="<?php echo e(route('plan_cuentas.auxiliar.habilitar',$datos->id)); ?>" class="badge-with-padding badge badge-success">
                                            <i class="fas fa-lg fa-arrow-alt-circle-up"></i>
                                        </a>
                                    </span>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('plan.cuentas.auxiliar.editar')): ?>
                                    <span class="tts:left tts-slideIn tts-custom" aria-label="Modificar" style="cursor: pointer;">
                                        <a href="<?php echo e(route('plan_cuentas.auxiliar.editar',$datos->id)); ?>" class="badge-with-padding badge badge-warning">
                                            <i class="fas fa-lg fa-edit text-white"></i>
                                        </a>
                                    </span>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="d-flex justify-content-end font-roboto-12">
            <?php echo $plan_cuentas_auxiliares->links(); ?>

        </div>
    </div>
</div><?php /**PATH D:\SistemaVentas\ventas\resources\views/plan_cuentas_auxiliares/partials/table.blade.php ENDPATH**/ ?>