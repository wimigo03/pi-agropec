<br>
**Contables<?php /**PATH D:\SistemaVentas\ventas\resources\views/sucursal/partials/datos_contables_editar.blade.php ENDPATH**/ ?>