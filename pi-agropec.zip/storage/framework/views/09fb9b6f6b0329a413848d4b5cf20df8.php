<!DOCTYPE html>

<style>
    .select2 + .select2-container .select2-selection__rendered {
        font-size: 11px;
    }
    .select2-results__option {
        font-size: 13px;
    }
    .obligatorio {
        border: 1px solid red !important;
    }
</style>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('categorias.partials.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="#" method="post" id="form">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('categorias.partials.form-create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
    <div class="form-group row">
        <div class="col-md-12 text-right">
            <button class="btn btn-outline-primary font-verdana" type="button" onclick="procesar();">
                <i class="fas fa-paper-plane"></i>&nbsp;Procesar
            </button>
            <button class="btn btn-outline-danger font-verdana" type="button" onclick="cancelar();">
                &nbsp;<i class="fas fa-times"></i>&nbsp;Cancelar
            </button>
            <i class="fa fa-spinner custom-spinner fa-spin fa-lg fa-fw spinner-btn" style="display: none;"></i>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    <?php echo $__env->make('layouts.notificaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ready(function() {
            $('.select2').select2({
                theme: "bootstrap4",
                placeholder: "--Seleccionar--",
                width: '100%'
            });
            $("#subMenuCategorias").hide();
        });

        $("#toggleSubMenu").click(function(){
            $("#subMenuCategorias").slideToggle(250);
        });
        
        function procesar() {
            var url = "<?php echo e(route('categorias.store')); ?>";
            $("#form").attr('action', url);
            $(".btn").hide();
            $(".spinner-btn").show();
            $("#form").submit();
        }

        function cancelar(){
            $(".btn").hide();
            $(".spinner-btn").show();
            var id = $("#empresa_id").val();
            var status_platos = '[]';
            var status_insumos = '[]';
            var url = "<?php echo e(route('categorias.index',[':id',':status_platos',':status_insumos'])); ?>";
            url = url.replace(':id',id);
            url = url.replace(':status_platos',status_platos);
            url = url.replace(':status_insumos',status_insumos);
            window.location.href = url;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SistemaVentas\ventas\resources\views/categorias/create.blade.php ENDPATH**/ ?>