<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>DETALLE DEL PRODUCTO</title>
	<style>
		body {
			font-family: verdana,arial,helvetica;
			font-size: 10px;
		}
		.table-titulo {
			width: 100%;
		}
		.table-data {
			width: 100%;
			border-collapse: collapse;
			border-bottom: 1px solid #000000;
			border-top: 1px solid #000000;
		}
		tr,td {
			padding: 5px;
		}
	</style>
</head>
<body>
	<table class="table-titulo">
		<tr>
			<td align="center">
				<h2>DETALLE DEL PRODUCTO</h2>
			</td>
		</tr>
	</table>
	<table width="100%">
        <tr>
            <td width="50%">
                <table width="100%">
                    <tr>
                        <td>
                            <b>EMPRESA.- </b>
                        </td>
                        <td>
                            <?php echo e($producto->empresa->nombre_comercial); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <b>CATEGORIA MASTER.- </b>
                        </td>
                        <td>
                            <?php echo e($producto->categoria_master); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <b>CATEGORIA.- </b>
                        </td>
                        <td>
                            <?php echo e($producto->categoria != null ? $producto->categoria->nombre : '-'); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <b>PLAN DE CUENTA.- </b>
                        </td>
                        <td>
                            <?php echo e($producto->plan_cuenta != null ? $producto->plan_cuenta->nombre : '#'); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <b>NOMBRE.- </b>
                        </td>
                        <td>
                            <?php echo e($producto->nombre); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <b>NOMBRE EN LA FACTURA.- </b>
                        </td>
                        <td>
                            <?php echo e($producto->nombre_factura); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <b>UNIDAD DE MEDIDA.- </b>
                        </td>
                        <td>
                            <?php echo e($producto->unidad->nombre); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <b>CODIGO.- </b>
                        </td>
                        <td>
                            <?php echo e($producto->codigo); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <b>ESTADO.- </b>
                        </td>
                        <td>
                            <?php echo e($producto->status); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <b>DETALLE.- </b>
                        </td>
                        <td>
                            <?php echo e($producto->detalle); ?>

                        </td>
                    </tr>
                </table>
            </td>
            <td width="50%">
                <table width="100%">
                    <tr>
                        <td align="center">
                            <?php if($producto->foto_1 != null): ?>
                                <img src=<?php echo e(public_path($producto->foto_1)); ?> alt="<?php echo e($producto->foto_1); ?>" style="width: 200px; height:auto;"/>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td align="center">
                            <?php if($producto->foto_2 != null): ?>
                                <img src=<?php echo e(public_path($producto->foto_2)); ?> alt="<?php echo e($producto->foto_2); ?>" style="width: 200px; height:auto;"/>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td align="center">
                            <?php if($producto->foto_3 != null): ?>
                                <img src=<?php echo e(public_path($producto->foto_3)); ?> alt="<?php echo e($producto->foto_3); ?>" style="width: 200px; height:auto;"/>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
	</table>
</body>
</html><?php /**PATH D:\SistemaVentas\ventas\resources\views/productos/pdf.blade.php ENDPATH**/ ?>