<div class="form-group row">
    <div class="col-md-2 px-0 pr-1 font-roboto-12">
        <label for="tipo" class="d-inline">Tipo</label>
        <input type="text" value="<?php echo e($tipo); ?>" class="form-control font-roboto-12" disabled>
    </div>
    <div class="col-md-5 pr-1 pl-1 font-roboto-12">
        <label for="cliente_id" class="d-inline">Cliente</label>
        <input type="hidden" name="cliente_id" value="<?php echo e($categoria->cliente_id); ?>">
        <input type="text" value="<?php echo e($categoria->cliente->razon_social); ?>" class="form-control font-roboto-12" disabled>
    </div>
    <div class="col-md-5 px-0 pl-1 font-roboto-12">
        <label for="empresa_id" class="d-inline">Empresa</label>
        <input type="hidden" name="empresa_id" value="<?php echo e($categoria->empresa_id); ?>" id="empresa_id">
        <input type="text" value="<?php echo e($categoria->empresa->nombre_comercial); ?>" class="form-control font-roboto-12" disabled>
    </div>
</div>
<div class="form-group row">
    <div class="col-md-5 px-0 pr-1 font-roboto-12">
        <label for="parent_id" class="d-inline">Dependiente de</label>
        <input type="hidden" name="parent_id" value="<?php echo e($categoria->parent != null ? $categoria->parent->id : null); ?>">
        <input type="text" value="<?php echo e($categoria->parent != null ? $categoria->parent->nombre : null); ?>" class="form-control font-roboto-12" disabled>
    </div>
    <div class="col-md-5 pr-1 pl-1 font-roboto-12">
        <label for="categoria" class="d-inline">Categoria</label>
        <input type="text" name="categoria" value="<?php echo e($categoria->nombre); ?>" class="form-control font-roboto-12 obligatorio" oninput="this.value = this.value.toUpperCase()">
    </div>
    <div class="col-md-2 px-0 pl-1 font-roboto-12">
        <label for="codigo" class="d-inline">Codigo</label>
        <input type="text" name="codigo" value="<?php echo e($categoria->codigo); ?>" class="form-control font-roboto-12 obligatorio" oninput="this.value = this.value.toUpperCase()">
    </div>
</div>
<div class="form-group row">
    <div class="col-md-6 px-0 pr-1 font-roboto-12">
        <label for="detalle" class="d-inline">Detalle</label>
        <input type="text" name="detalle" value="<?php echo e($categoria->detalle); ?>" class="form-control font-roboto-12" oninput="this.value = this.value.toUpperCase()">
    </div>
    <div class="col-md-3 pr-1 pl-1 font-roboto-12">
        <label for="tipo" class="d-inline">Tipo</label>
        <input type="text" value="<?php echo e($tipo); ?>" class="form-control font-roboto-12" disabled>
    </div>
    <div class="col-md-3 px-0 pl-1 font-roboto-12">
        <label for="plan_cuenta" class="d-inline">Plan Cuenta</label>
        <select name="plan_cuenta_id" id="plan_cuenta_id" placeholder="--Seleccionar--" class="form-control select2 <?php echo e($errors->has('plan_cuenta_id') ? 'is-invalid' : ''); ?>">
            <?php $__currentLoopData = $plan_cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan_cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($plan_cuenta->id); ?>"
                    <?php if($plan_cuenta->id == request('plan_cuenta_id') || (isset($categoria) && $categoria->plan_cuenta_id == $plan_cuenta->id)): ?>
                        selected
                    <?php endif; ?>>
                    <?php echo e($plan_cuenta->nombre); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div><?php /**PATH D:\SistemaVentas\ventas\resources\views/categorias/partials/form-editar.blade.php ENDPATH**/ ?>